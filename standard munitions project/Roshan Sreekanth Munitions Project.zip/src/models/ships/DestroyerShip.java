package models.ships;

public class DestroyerShip extends Ship 
{
    public DestroyerShip()
    {
        this.setType("Destroyer");
    }
}
