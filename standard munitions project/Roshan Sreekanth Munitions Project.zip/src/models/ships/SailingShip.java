package models.ships;

public class SailingShip extends Ship
{
    public SailingShip()
    {
        this.setType("Sailing");
    }
}
