package models.ships;
public class AircraftCarrierShip extends Ship
{
    public AircraftCarrierShip()
    {
        this.setType("Aircraft Carrier");
    }
}
