package models.bombs;
public class BlastBomb extends Bomb 
{
    public BlastBomb()
    {
        this.setType("Blast Bomb");
    }    
}
