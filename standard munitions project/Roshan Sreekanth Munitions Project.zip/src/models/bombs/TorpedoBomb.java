package models.bombs;

public class TorpedoBomb extends Bomb 
{
    public TorpedoBomb()
    {
        this.setType("Torpedo");
    }
}
