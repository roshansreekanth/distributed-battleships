package models.bombs;

public class ArmorPiercingBomb extends Bomb
{
    public ArmorPiercingBomb()
    {
        this.setType("Armor Piercing");
    }
}