package models.bombs;

public interface BombFactory
{
    public Bomb create();
}
